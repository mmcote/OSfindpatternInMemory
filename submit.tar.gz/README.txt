(name ccid id)
(Brad Hanasyk hanasyk1 1301531)
(Michael Cote mmcote 1356556)

Commands
--------
make tests // compile and execute all tests with default pattern
make testX // compile and execute driverX with default pattern
make clean // remove all object files and test_results.txt

NOTE: To pass your own function just add p=(PATTERN) to the end of the command
